import qupath.lib.objects.PathAnnotationObject
import qupath.lib.scripting.QP

print("---------Finding WHOLE TISSUE annotation now...------")

deselectAll();
min_area = 20000.0;
min_hole_area = 50000.0;
classifier = "Tissue Classifier";

original_annotations = getAllObjects();
original_annotations_names = []
original_annotations.each {
    original_annotations_names.add(it.getName())
}

WHOLE_TISSUE = ""
original_annotations.find {
    if (it.getName()=="WHOLE TISSUE") {
        WHOLE_TISSUE = it
        return true
    }
    return false
}

if (WHOLE_TISSUE == "") {
    // WHOLE TISSUE not found
    createAnnotationsFromPixelClassifier(classifier, min_area, min_hole_area, "INCLUDE_IGNORED","SELECT_NEW")
    WHOLE_TISSUE = getSelectedObjects();
    WHOLE_TISSUE = WHOLE_TISSUE[0]
    selectObjectsByClassification("Negative")
    intestinal_ann = getSelectedObjects()
    new_roi = WHOLE_TISSUE.getROI()
    intestinal_ann.each {
        neg_roi = it.getROI()
        new_roi = RoiTools.combineROIs(new_roi, neg_roi, RoiTools.CombineOp.SUBTRACT)
        WHOLE_TISSUE.setROI(new_roi)
    }
    
    WHOLE_TISSUE.setName("WHOLE TISSUE");
    WHOLE_TISSUE.setLocked(false)
}
region_class = WHOLE_TISSUE.getPathClass();
whole_tissue_geo = WHOLE_TISSUE.getROI().getGeometry()
plane = WHOLE_TISSUE.getROI().getImagePlane()

print("---------Whole tissue annotation found-----------------")
print("---------Restricting annotations to this...------------")

classification_names = ["Tumor","Immune cells","Healthy"];
classifier = "Tissue Classifier";


imageData = getCurrentImageData()
hierarchy = imageData.getHierarchy()