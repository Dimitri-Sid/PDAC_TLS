def entry = getProjectEntry()

imagedata = entry.readImageData()

selectAnnotations()
annotations = getSelectedObjects()
annotations_to_measure = []
annotations.each {A ->
    if (A.getName() == "WHOLE TISSUE") {
        print(A.getName() + " WHOLE TISSUE")
        return;
    }
    if (!(A.getName().contains("tight"))) {
        print(A.getName() + " does not contain tight")
        return;
    }

    print("Adding " + A.getName() + " to measure")
    annotations_to_measure.push(A)
}
getCurrentHierarchy().getSelectionModel().setSelectedObjects(annotations_to_measure, annotations_to_measure[0])
print("Annotations to measure: " + getSelectedObjects())
print("Number annotations to measure: " + getSelectedObjects().size())

print("Annotations selected...")
if (imagedata.ImageType==BRIGHTFIELD_OTHER) {
    print("Starting to measure collagen...")
    addPixelClassifierMeasurements("TrichromeBlue", "TrichromeBlue")
}
else if (imagedata.ImageType==BRIGHTFIELD_H_DAB)  {
    print("Starting to measure CHP...")
    addPixelClassifierMeasurements("CHP+", "CHP+")
}