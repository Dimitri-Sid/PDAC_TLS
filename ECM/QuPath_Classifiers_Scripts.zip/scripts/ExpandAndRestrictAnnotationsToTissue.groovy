print("---------Restricting annotations to WHOLE TISSUE and expanding...------------")

original_annotations = getAllObjects();
original_annotations_names = []
original_annotations.each {
    original_annotations_names.add(it.getName())
}
WHOLE_TISSUE = ""
original_annotations.find {
    if (it.getName()=="WHOLE TISSUE") {
        WHOLE_TISSUE = it
        return true
    }
    return false
}
region_class = WHOLE_TISSUE.getPathClass();
whole_tissue_geo = WHOLE_TISSUE.getROI().getGeometry()
plane = WHOLE_TISSUE.getROI().getImagePlane()

classification_names = ["TLS","TLS_weak"];

imageData = getCurrentImageData()
hierarchy = imageData.getHierarchy()

distances_to_expand = [200]

for (classification_name in classification_names)
{
    print("\tCollecting original " + classification_name + " annotations now...")
    selectObjectsByClassification(classification_name)
    selected_objects = getSelectedObjects();
    if (selected_objects.size()==0) { continue; }

    print("\tRestricting " + classification_name + " annotations to tissue now...")
    annotations_to_ring = []
    for (d in distances_to_expand) {
        annotations_to_ring.push([]) // list for each distance of annotations to do
    }
    for (selected_object in selected_objects) {
        name = selected_object.getName()
        need_to_tighten = !original_annotations_names.contains(name + "_tight")
        selected_object_geo = selected_object.getROI().getGeometry();
        intersect_geo = selected_object_geo.intersection(whole_tissue_geo)
        intersect_roi = GeometryTools.geometryToROI(intersect_geo, plane)
        
        if (intersect_roi.getArea()==0) { continue; }

        idx = 0
        for (d in distances_to_expand) {
            if (!original_annotations_names.contains(name + "_tight_ring_" + d)) {
                annotations_to_ring[idx].push(selected_object)
            }
            idx = idx + 1
        }

        if (need_to_tighten) {
            intersect_annotation = PathObjects.createAnnotationObject(intersect_roi)
            intersect_annotation.setName(name+"_tight")
            insertObjects(intersect_annotation)
            intersect_annotation.setPathClass(region_class);
        }
    }

    print("\tRestricted " + classification_name + " annotations to tissue")
    
    idx = -1
    for (d in distances_to_expand) {
        idx = idx + 1
        if (annotations_to_ring[idx].size()==0) { print("None here to ring..."); continue; }
        print("\t\tRinging with a distance of " + d + " microns...")
        selectObjects(annotations_to_ring[idx])
        duplicateSelectedAnnotations(hierarchy) // make duplicates of these so as not to destroy them in the filling in step (I think this will create them with with original classification, not Region*)
        ALL_OBJECTS = getAllObjects(); // get all objects present before dilation adds new ones
        print("\tFilling in now...") // this will fill in some holes in tumor annotations to make it faster to compute the dilation later. the updated annotations are not used for downstream analysis, instead their tight versions are
        runPlugin('qupath.lib.plugins.objects.FillAnnotationHolesPlugin', '{}')
        print("\tFilled in.")
        print("\tExpanding now...")
        runPlugin('qupath.lib.plugins.objects.DilateAnnotationPlugin', '{"radiusMicrons":'+d+',"lineCap":"ROUND","removeInterior":true,"constrainToParent":false}')

        removeObjects(annotations_to_ring[idx], true) // these are no longer necessary as they have been duplicated (prior to filling in) and then ringed for restriction next

        print("\tExpanded by " + d + " microns for " + classification_name + " with n = " + annotations_to_ring[idx].size())
        print("\tRestricting these rings to the tissue now...")

        for (object in getAllObjects())
        {
            if (object in ALL_OBJECTS) {continue;}
            name = object.getName()
            object.setName(name+"_tight_ring_"+d);
            object.setPathClass(region_class);
            object_roi = object.getROI();
            object_geo = object_roi.getGeometry();
            object_geo = object_geo.intersection(whole_tissue_geo);
            object.setROI(GeometryTools.geometryToROI(object_geo, plane));
        }
        print("\tRings restricted to tissue with d = " + d)
    }
    
}


print("---------Removing duplicates---------")
ALL_OBJECTS = getAllObjects();
current_idx = ALL_OBJECTS.size()
deleted_inds = []
for ( i = ALL_OBJECTS.size()-1; i >= 0 ; i-- ) {
    current_idx -= 1
    for ( j = current_idx+1; j < ALL_OBJECTS.size(); j++ ) {
        if (!deleted_inds.contains(j) && ALL_OBJECTS[i].getName()==ALL_OBJECTS[j].getName()) {
            removeObject(ALL_OBJECTS[j], true)
            deleted_inds.push(j)
        }
    }
}